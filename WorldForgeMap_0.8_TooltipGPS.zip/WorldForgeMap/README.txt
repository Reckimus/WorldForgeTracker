WorldForgeMap 0.8 - Tooltip + GPS build

Install:
1. Delete the old Interface/AddOns/WorldForgeMap folder.
2. Copy this WorldForgeMap folder into Interface/AddOns/.
3. Restart WoW or /reload.

What it does:
- Shows BronzebeardMaps World Forge object/item pins on the 3.3.5 world map.
- Uses small yellow diamond pins.
- Mouse over a diamond to see the item/object name and coords.
- Left-click a diamond to set a GPS target.
- If TomTom is installed, the addon will use TomTom's Crazy Arrow.
- If TomTom is not installed, the addon shows a small fallback GPS panel with direction and distance.

Commands:
/wfm                 Open search window
/wfm search name     Search and open the first matching item location
/wfm gps name        Search and set GPS target
/wfm gps off         Clear GPS target
/wfm count           Show loaded/current zone pin counts
/wfm debug           Show map geometry debug info
/wfm showall         Show all zone pins
/wfm hideall         Only show selected/search pins

Notes:
- The hover/click system uses a manual cursor scanner based on LootCollector's safer world-map placement method.
- Pins are parented to WorldMapButton, but positioned against WorldMapDetailFrame so the coordinates line up with the actual map image.
