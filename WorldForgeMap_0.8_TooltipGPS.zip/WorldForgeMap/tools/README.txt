The database in this release is already generated.
This folder is left for future scraper/importer tools if the website data changes.
