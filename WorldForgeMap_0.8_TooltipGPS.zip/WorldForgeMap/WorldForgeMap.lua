local ADDON = "WorldForgeMap"
local WFM = {}
_G.WorldForgeMapRuntime = WFM

WorldForgeMap_Settings = WorldForgeMap_Settings or {}
if WorldForgeMap_Settings.showAllPins == nil then WorldForgeMap_Settings.showAllPins = true end
WorldForgeMap_Settings.minimapAngle = WorldForgeMap_Settings.minimapAngle or 225
WorldForgeMap_Settings.maxSearchResults = WorldForgeMap_Settings.maxSearchResults or 120

local PIN_TEXTURE = "Interface\\AddOns\\WorldForgeMap\\media\\pin_diamond"
local SELECTED_PIN_TEXTURE = "Interface\\AddOns\\WorldForgeMap\\media\\pin_diamond_selected"
local PIN_SIZE = 13
local SELECTED_PIN_SIZE = 21
local HOVER_HIT_RADIUS = 18
local MINI_ICON_TEXTURE = "Interface\\Icons\\INV_Misc_Map_01"

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99WorldForgeMap:|r " .. tostring(msg))
end

local function CleanText(s)
    s = tostring(s or "")
    s = string.lower(s)
    s = string.gsub(s, "[`'’‘]", "")
    s = string.gsub(s, "[^a-z0-9]+", "")
    return s
end

local function Contains(haystack, needle)
    if not needle or needle == "" then return true end
    return string.find(CleanText(haystack), CleanText(needle), 1, true) ~= nil
end

local function CoordsText(loc)
    return string.format("%.1f, %.1f", tonumber(loc and loc.x or 0) or 0, tonumber(loc and loc.y or 0) or 0)
end

-- Website-style hover label used by map pins.
local hoverLabel = CreateFrame("Frame", "WorldForgeMapHoverLabel", UIParent)
hoverLabel:SetFrameStrata("TOOLTIP")
hoverLabel:SetWidth(160)
hoverLabel:SetHeight(30)
hoverLabel:Hide()
hoverLabel:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true,
    tileSize = 16,
    edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
hoverLabel:SetBackdropColor(0, 0, 0, 0.96)
hoverLabel:SetBackdropBorderColor(0.45, 0.45, 0.45, 1)
hoverLabel.text = hoverLabel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
hoverLabel.text:SetPoint("CENTER", hoverLabel, "CENTER", 0, 0)
hoverLabel.text:SetJustifyH("CENTER")
hoverLabel.text:SetTextColor(1, 0.82, 0)

hoverLabel:SetScript("OnUpdate", function(self)
    local x, y = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale() or 1
    self:ClearAllPoints()
    self:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", (x / scale) + 18, (y / scale) + 20)
end)

local function ShowPinHoverLabel(loc)
    if not loc then return end

    local labelText = string.format("%s (%.1f, %.1f)", tostring(loc.name or "Unknown"), tonumber(loc.x or 0) or 0, tonumber(loc.y or 0) or 0)

    -- Keep the small website-style label, but also drive the real GameTooltip.
    -- On the 3.3.5 world map, some layers can swallow normal pin OnEnter events;
    -- the manual scanner below calls this function directly.
    hoverLabel.text:SetText(labelText)
    local textWidth = hoverLabel.text:GetStringWidth() or 120
    hoverLabel:SetWidth(math.max(120, textWidth + 26))
    hoverLabel:SetFrameStrata("TOOLTIP")
    hoverLabel:Show()

    if GameTooltip then
        if WorldMapFrame and WorldMapFrame:IsShown() then
            GameTooltip:SetParent(WorldMapFrame)
            GameTooltip:SetFrameStrata("TOOLTIP")
            GameTooltip:SetFrameLevel((WorldMapFrame:GetFrameLevel() or 1) + 300)
        else
            GameTooltip:SetParent(UIParent)
            GameTooltip:SetFrameStrata("TOOLTIP")
        end

        GameTooltip:SetOwner(WorldMapButton or UIParent, "ANCHOR_CURSOR")
        GameTooltip:ClearLines()
        GameTooltip:AddLine(labelText, 1, 0.82, 0)
        GameTooltip:AddLine("Left-click: set GPS arrow", 0.45, 1, 0.45)
        GameTooltip:Show()
        if WorldForgeMapRuntime then WorldForgeMapRuntime.tooltipActive = true end
    end
end

local function HidePinHoverLabel()
    hoverLabel:Hide()
    if GameTooltip and WorldForgeMapRuntime and WorldForgeMapRuntime.tooltipActive then
        GameTooltip:Hide()
        GameTooltip:SetParent(UIParent)
    end
    if WorldForgeMapRuntime then WorldForgeMapRuntime.tooltipActive = false end
end

local function CursorPositionForFrame(frame)
    local x, y = GetCursorPosition()
    local scale = (frame and frame.GetEffectiveScale and frame:GetEffectiveScale()) or UIParent:GetEffectiveScale() or 1
    return x / scale, y / scale
end

local function GetMapGeometry()
    local button = WorldMapButton
    local detail = WorldMapDetailFrame or WorldMapButton
    if not button or not detail then return nil end

    local mapWidth, mapHeight = detail:GetWidth(), detail:GetHeight()
    if not mapWidth or not mapHeight or mapWidth <= 0 or mapHeight <= 0 then return nil end

    local buttonLeft, buttonTop = button:GetLeft(), button:GetTop()
    local detailLeft, detailTop = detail:GetLeft(), detail:GetTop()

    if not buttonLeft or not buttonTop or not detailLeft or not detailTop then
        -- Fallback for clients/layouts that do not expose WorldMapDetailFrame geometry.
        return {
            button = button,
            detail = button,
            left = button:GetLeft(),
            top = button:GetTop(),
            bottom = button:GetBottom(),
            width = button:GetWidth(),
            height = button:GetHeight(),
            offsetX = 0,
            offsetY = 0,
        }
    end

    return {
        button = button,
        detail = detail,
        left = detailLeft,
        top = detailTop,
        bottom = detail:GetBottom(),
        width = mapWidth,
        height = mapHeight,
        offsetX = detailLeft - buttonLeft,
        offsetY = detailTop - buttonTop,
    }
end

local function SameLocation(a, b)
    if not a or not b then return false end
    return a.name == b.name
       and a.mapFile == b.mapFile
       and tonumber(a.x) == tonumber(b.x)
       and tonumber(a.y) == tonumber(b.y)
end

local function CurrentMapFile()
    if GetMapInfo then
        local f = GetMapInfo()
        if f and f ~= "" then return f end
    end
    return nil
end

local function CurrentZoneName()
    -- The selected zone name in 3.3.5 is easiest to recover by matching current map file
    -- after dropdown changes. This fallback keeps count/debug messages useful.
    local f = CurrentMapFile()
    if f and WFM.zoneNameByMapFile then return WFM.zoneNameByMapFile[f] end
    return nil
end

local function EnsureWorldMapShown()
    if WorldMapFrame and not WorldMapFrame:IsShown() then
        ToggleFrame(WorldMapFrame)
    end
end

local function TrySetMapToLocation(loc)
    if not loc then return false end

    -- Some 3.3.5 clients/private servers expose SetMapByID. Use it if data ever has zoneID.
    if loc.zoneID and SetMapByID then
        SetMapByID(loc.zoneID)
        return true
    end

    -- WotLK-safe method: scan continent/zone dropdowns until GetMapInfo() matches.
    if not SetMapZoom or not GetMapContinents or not GetMapZones then return false end

    local targetMap = loc.mapFile
    local targetName = CleanText(loc.zoneName)

    local continents = { GetMapContinents() }
    for c = 1, #continents do
        local zones = { GetMapZones(c) }
        for z = 1, #zones do
            if targetName ~= "" and CleanText(zones[z]) == targetName then
                SetMapZoom(c, z)
                return true
            end
        end
    end

    -- If names were localized/different, brute-force by map file.
    if targetMap then
        for c = 1, #continents do
            local zones = { GetMapZones(c) }
            for z = 1, #zones do
                SetMapZoom(c, z)
                if CurrentMapFile() == targetMap then
                    return true
                end
            end
        end
    end

    return false
end

function WFM:BuildIndexes()
    self.byMapFile = WorldForgeMap_ObjectLocations or {}
    self.zoneNameByMapFile = {}
    self.all = {}
    self.byName = {}
    self.total = 0
    self.uniqueNames = 0

    for mapFile, list in pairs(self.byMapFile) do
        if type(list) == "table" then
            for _, loc in ipairs(list) do
                if type(loc) == "table" and loc.name and loc.x and loc.y then
                    loc.mapFile = loc.mapFile or mapFile
                    self.zoneNameByMapFile[loc.mapFile] = loc.zoneName or loc.mapFile

                    local key = CleanText(loc.name)
                    if key ~= "" then
                        if not self.byName[key] then
                            self.byName[key] = {}
                            self.uniqueNames = self.uniqueNames + 1
                        end
                        table.insert(self.byName[key], loc)
                    end

                    table.insert(self.all, loc)
                    self.total = self.total + 1
                end
            end
        end
    end

    table.sort(self.all, function(a, b)
        local an = tostring(a.name or "")
        local bn = tostring(b.name or "")
        if an == bn then
            local az = tostring(a.zoneName or a.mapFile or "")
            local bz = tostring(b.zoneName or b.mapFile or "")
            if az == bz then return (a.x or 0) < (b.x or 0) end
            return az < bz
        end
        return an < bn
    end)
end

function WFM:Search(query)
    local results = {}
    local limit = WorldForgeMap_Settings.maxSearchResults or 120
    query = query or ""

    for _, loc in ipairs(self.all or {}) do
        if Contains(loc.name, query) or Contains(loc.zoneName, query) or Contains(loc.mapFile, query) then
            table.insert(results, loc)
            if #results >= limit then break end
        end
    end

    return results
end

function WFM:ZoneCount(mapFile)
    local list = self.byMapFile and self.byMapFile[mapFile]
    return list and #list or 0
end

-- Delayed redraw helper.
local drawScheduler = CreateFrame("Frame")
drawScheduler:Hide()
drawScheduler.delay = 0

drawScheduler:SetScript("OnUpdate", function(self, elapsed)
    self.delay = self.delay - elapsed
    if self.delay <= 0 then
        self:Hide()
        if WFM.DrawPins then WFM:DrawPins() end
    end
end)

function WFM:ScheduleDraw(delay)
    drawScheduler.delay = delay or 0.05
    drawScheduler:Show()
end

function WFM:GetMapSurface()
    return WorldMapButton
end

function WFM:GetPin(index)
    self.pins = self.pins or {}
    if self.pins[index] then return self.pins[index] end

    local parent = self:GetMapSurface()
    local pin = CreateFrame("Button", nil, parent)
    pin:SetWidth(PIN_SIZE)
    pin:SetHeight(PIN_SIZE)
    pin:EnableMouse(true)
    pin:SetHitRectInsets(-4, -4, -4, -4)
    pin:SetFrameStrata("FULLSCREEN")
    pin:SetFrameLevel((parent:GetFrameLevel() or 1) + 100)
    pin:Hide()

    pin.icon = pin:CreateTexture(nil, "OVERLAY")
    pin.icon:SetAllPoints()
    pin.icon:SetTexture(PIN_TEXTURE)

    pin:SetScript("OnEnter", function(self)
        if not self.loc then return end
        ShowPinHoverLabel(self.loc)
    end)

    pin:SetScript("OnLeave", function()
        HidePinHoverLabel()
    end)

    pin:SetScript("OnClick", function(self, button)
        if self.loc and button == "LeftButton" then
            WFM:SetGPSTarget(self.loc)
        end
    end)

    self.pins[index] = pin
    return pin
end

function WFM:HidePins()
    if not self.pins then return end
    for _, pin in ipairs(self.pins) do
        pin.loc = nil
        pin:Hide()
    end
end

local function NormalizedCoord(v)
    v = tonumber(v) or 0
    if v > 1 then v = v / 100 end
    return v
end

function WFM:DrawPins()
    local surface = self:GetMapSurface()
    if not WorldMapFrame or not WorldMapFrame:IsShown() or not surface then return end

    self:HidePins()

    local mapFile = CurrentMapFile()
    if not mapFile then return end

    local list = {}
    if WorldForgeMap_Settings.showAllPins then
        local zoneList = self.byMapFile and self.byMapFile[mapFile]
        if zoneList then
            for _, loc in ipairs(zoneList) do table.insert(list, loc) end
        end
    end

    if self.selectedLocation and self.selectedLocation.mapFile == mapFile then
        local already = false
        for _, loc in ipairs(list) do
            if SameLocation(loc, self.selectedLocation) then already = true break end
        end
        if not already then table.insert(list, self.selectedLocation) end
    end

    self.visibleLocations = list

    local geom = GetMapGeometry()
    if not geom then return end

    for i, loc in ipairs(list) do
        local x = NormalizedCoord(loc.x)
        local y = NormalizedCoord(loc.y)
        if x > 0 and y > 0 and x <= 1 and y <= 1 then
            local pin = self:GetPin(i)
            pin.loc = loc
            pin:SetParent(geom.button)
            pin:ClearAllPoints()
            -- Match LootCollector's safer 3.3.5 placement method:
            -- parent to WorldMapButton but position against the actual WorldMapDetailFrame image.
            pin:SetPoint("CENTER", geom.button, "TOPLEFT", geom.offsetX + (x * geom.width), geom.offsetY - (y * geom.height))
            if SameLocation(loc, self.selectedLocation) then
                pin:SetWidth(SELECTED_PIN_SIZE)
                pin:SetHeight(SELECTED_PIN_SIZE)
                pin.icon:SetTexture(SELECTED_PIN_TEXTURE)
            else
                pin:SetWidth(PIN_SIZE)
                pin:SetHeight(PIN_SIZE)
                pin.icon:SetTexture(PIN_TEXTURE)
            end
            pin:SetFrameLevel((geom.button:GetFrameLevel() or 1) + 100)
            pin:Show()
        end
    end
end

function WFM:FindHoveredLocation()
    local surface = self:GetMapSurface()
    if not WorldMapFrame or not WorldMapFrame:IsShown() or not surface or not surface:IsVisible() then
        return nil
    end

    local geom = GetMapGeometry()
    if not geom or not geom.left or not geom.bottom or not geom.width or not geom.height then
        return nil
    end

    local cursorX, cursorY = CursorPositionForFrame(geom.detail)
    if cursorX < geom.left or cursorX > (geom.left + geom.width) or cursorY < geom.bottom or cursorY > (geom.bottom + geom.height) then
        return nil
    end

    local mapX = cursorX - geom.left
    local mapYFromTop = geom.height - (cursorY - geom.bottom)
    local bestLoc = nil
    local bestDistSq = (HOVER_HIT_RADIUS * HOVER_HIT_RADIUS)

    local list = self.visibleLocations
    if not list or #list == 0 then
        local mapFile = CurrentMapFile()
        list = self.byMapFile and self.byMapFile[mapFile]
    end
    if not list then return nil end

    for _, loc in ipairs(list) do
        local x = NormalizedCoord(loc.x) * geom.width
        local y = NormalizedCoord(loc.y) * geom.height
        local dx = mapX - x
        local dy = mapYFromTop - y
        local d2 = (dx * dx) + (dy * dy)
        if d2 <= bestDistSq then
            bestDistSq = d2
            bestLoc = loc
        end
    end

    return bestLoc
end

function WFM:UpdateManualHover()
    local loc = self:FindHoveredLocation()
    if loc then
        if not SameLocation(loc, self.hoveredLocation) then
            self.hoveredLocation = loc
            ShowPinHoverLabel(loc)
        end
    else
        if self.hoveredLocation then
            self.hoveredLocation = nil
            HidePinHoverLabel()
        end
    end
end

function WFM:OpenToLocation(loc)
    if not loc then return end
    self.selectedLocation = loc
    EnsureWorldMapShown()
    TrySetMapToLocation(loc)
    self:ScheduleDraw(0.25)
    Print("Showing " .. tostring(loc.name) .. " - " .. tostring(loc.zoneName or loc.mapFile) .. " " .. CoordsText(loc))
end

-- GPS / arrow support ------------------------------------------------------
local function ResolveContinentZoneIndex(loc)
    if not loc or not GetMapContinents or not GetMapZones then return nil, nil end
    local target = CleanText(loc.zoneName or loc.mapFile)
    if target == "" then return nil, nil end

    local continents = { GetMapContinents() }
    for c = 1, #continents do
        local zones = { GetMapZones(c) }
        for z = 1, #zones do
            if CleanText(zones[z]) == target then
                return c, z, zones[z]
            end
        end
    end
    return nil, nil
end

local function TomTomAvailable()
    return (_G.TomTom and (_G.TomTom.AddZWaypoint or _G.TomTom.AddWaypoint)) or _G.TomTomAddZWaypoint
end

function WFM:ClearTomTomWaypoint()
    if self.tomtomUID then
        if _G.TomTom and _G.TomTom.RemoveWaypoint then
            TomTom:RemoveWaypoint(self.tomtomUID)
        elseif _G.TomTomRemoveWaypoint then
            TomTomRemoveWaypoint(self.tomtomUID)
        end
        self.tomtomUID = nil
    end
    if _G.TomTom and _G.TomTom.SetCrazyArrow then
        TomTom:SetCrazyArrow(nil)
    elseif _G.TomTomSetCrazyArrow then
        TomTomSetCrazyArrow(nil)
    end
end

function WFM:AddTomTomWaypoint(loc)
    if not loc or not TomTomAvailable() then return false end
    local c, z = ResolveContinentZoneIndex(loc)
    if not c or not z then return false end

    self:ClearTomTomWaypoint()

    local desc = string.format("%s (%.1f, %.1f)", tostring(loc.name or "World Forge"), tonumber(loc.x or 0) or 0, tonumber(loc.y or 0) or 0)
    local uid

    if _G.TomTom and _G.TomTom.AddZWaypoint then
        local ok, result = pcall(function() return TomTom:AddZWaypoint(c, z, tonumber(loc.x) or 0, tonumber(loc.y) or 0, desc, false, false, true) end)
        if ok then uid = result end
    elseif _G.TomTomAddZWaypoint then
        local ok, result = pcall(function() return TomTomAddZWaypoint(c, z, tonumber(loc.x) or 0, tonumber(loc.y) or 0, desc, false, false, true) end)
        if ok then uid = result end
    end

    if not uid and _G.TomTom and _G.TomTom.AddWaypoint then
        local ok, result = pcall(function()
            return TomTom:AddWaypoint(c, z, NormalizedCoord(loc.x), NormalizedCoord(loc.y), { title = desc, persistent = false, minimap = true, world = true })
        end)
        if ok then uid = result end
    end

    if uid then
        self.tomtomUID = uid
        if _G.TomTom and _G.TomTom.SetCrazyArrow then
            TomTom:SetCrazyArrow(uid, 15, desc)
        elseif _G.TomTomSetCrazyArrow then
            TomTomSetCrazyArrow(uid, 15, desc)
        end
        return true
    end

    return false
end

local gpsFrame = CreateFrame("Frame", "WorldForgeMapGPSFrame", UIParent)
gpsFrame:SetWidth(245)
gpsFrame:SetHeight(72)
gpsFrame:SetPoint("TOP", UIParent, "TOP", 0, -120)
gpsFrame:SetFrameStrata("DIALOG")
gpsFrame:EnableMouse(true)
gpsFrame:SetMovable(true)
gpsFrame:RegisterForDrag("LeftButton")
gpsFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
gpsFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
gpsFrame:Hide()
gpsFrame:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true,
    tileSize = 16,
    edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
gpsFrame:SetBackdropColor(0, 0, 0, 0.90)
gpsFrame:SetBackdropBorderColor(0.75, 0.65, 0.20, 1)

gpsFrame.title = gpsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
gpsFrame.title:SetPoint("TOP", 0, -8)
gpsFrame.title:SetWidth(200)
gpsFrame.title:SetText("World Forge GPS")

gpsFrame.dir = gpsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
gpsFrame.dir:SetPoint("LEFT", 16, -8)
gpsFrame.dir:SetTextColor(1, 0.82, 0)
gpsFrame.dir:SetText("--")

gpsFrame.info = gpsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
gpsFrame.info:SetPoint("LEFT", gpsFrame.dir, "RIGHT", 18, 0)
gpsFrame.info:SetWidth(160)
gpsFrame.info:SetJustifyH("LEFT")
gpsFrame.info:SetText("")

gpsFrame.close = CreateFrame("Button", nil, gpsFrame, "UIPanelCloseButton")
gpsFrame.close:SetWidth(22)
gpsFrame.close:SetHeight(22)
gpsFrame.close:SetPoint("TOPRIGHT", 2, 2)
gpsFrame.close:SetScript("OnClick", function()
    WFM.gpsTarget = nil
    WFM:ClearTomTomWaypoint()
    gpsFrame:Hide()
end)

local function SaveMapState()
    local c = GetCurrentMapContinent and GetCurrentMapContinent() or nil
    local z = GetCurrentMapZone and GetCurrentMapZone() or nil
    local dl = GetCurrentMapDungeonLevel and GetCurrentMapDungeonLevel() or nil
    return c, z, dl
end

local function RestoreMapState(c, z, dl)
    if c and z and SetMapZoom then SetMapZoom(c, z) end
    if dl and SetDungeonMapLevel then SetDungeonMapLevel(dl) end
end

function WFM:GetPlayerMapPositionSafe()
    local x, y = GetPlayerMapPosition("player")
    if x and y and (x ~= 0 or y ~= 0) then return x, y end

    if SetMapToCurrentZone then
        local c, z, dl = SaveMapState()
        SetMapToCurrentZone()
        x, y = GetPlayerMapPosition("player")
        RestoreMapState(c, z, dl)
    end

    return x, y
end

local function DirectionText(dx, dy)
    -- Map Y grows south/down, so negative dy means north.
    local ns = ""
    local ew = ""
    if dy < -0.01 then ns = "N" elseif dy > 0.01 then ns = "S" end
    if dx > 0.01 then ew = "E" elseif dx < -0.01 then ew = "W" end
    local d = ns .. ew
    if d == "" then d = "HERE" end
    return d
end

function WFM:UpdateGPS()
    local loc = self.gpsTarget
    if not loc then gpsFrame:Hide(); return end

    local px, py = self:GetPlayerMapPositionSafe()
    if not px or not py or (px == 0 and py == 0) then
        gpsFrame.dir:SetText("?")
        gpsFrame.info:SetText("Open/enter the target zone:\n" .. tostring(loc.zoneName or loc.mapFile))
        return
    end

    local tx, ty = NormalizedCoord(loc.x), NormalizedCoord(loc.y)
    local dx, dy = tx - px, ty - py
    local dist = math.sqrt((dx * dx) + (dy * dy)) * 100
    local dir = DirectionText(dx, dy)

    gpsFrame.dir:SetText(dir)
    gpsFrame.info:SetText(string.format("%s\n%.1f, %.1f  |  %.1f away", tostring(loc.name or "World Forge"), tonumber(loc.x or 0) or 0, tonumber(loc.y or 0) or 0, dist))
end

local gpsTicker = CreateFrame("Frame")
gpsTicker.elapsed = 0
gpsTicker:SetScript("OnUpdate", function(self, elapsed)
    if not WFM.gpsTarget then return end
    self.elapsed = self.elapsed + elapsed
    if self.elapsed < 0.20 then return end
    self.elapsed = 0
    WFM:UpdateGPS()
end)

function WFM:SetGPSTarget(loc)
    if not loc then return end
    self.gpsTarget = loc
    self.selectedLocation = loc
    local usedTomTom = self:AddTomTomWaypoint(loc)
    gpsFrame:Show()
    self:UpdateGPS()
    self:ScheduleDraw(0.01)
    if usedTomTom then
        Print("GPS set with TomTom: " .. tostring(loc.name) .. " - " .. tostring(loc.zoneName) .. " " .. CoordsText(loc))
    else
        Print("GPS set: " .. tostring(loc.name) .. " - " .. tostring(loc.zoneName) .. " " .. CoordsText(loc) .. " | Install TomTom for a real rotating arrow.")
    end
end

function WFM:HandleMapClick(button)
    if button ~= "LeftButton" then return end
    local loc = self:FindHoveredLocation()
    if loc then
        self:SetGPSTarget(loc)
    end
end

-- Search UI
local frame = CreateFrame("Frame", "WorldForgeMapSearchFrame", UIParent)
frame:SetWidth(460)
frame:SetHeight(505)
frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
frame:SetFrameStrata("DIALOG")
frame:EnableMouse(true)
frame:SetMovable(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
frame:Hide()
frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true,
    tileSize = 32,
    edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
})

frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
frame.title:SetPoint("TOP", 0, -15)
frame.title:SetText("World Forge Search")

frame.close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
frame.close:SetPoint("TOPRIGHT", -4, -4)

frame.status = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
frame.status:SetPoint("TOPLEFT", 24, -42)
frame.status:SetJustifyH("LEFT")
frame.status:SetText("Loading...")

frame.searchBox = CreateFrame("EditBox", "WorldForgeMapSearchBox", frame, "InputBoxTemplate")
frame.searchBox:SetWidth(300)
frame.searchBox:SetHeight(24)
frame.searchBox:SetPoint("TOPLEFT", 28, -67)
frame.searchBox:SetAutoFocus(false)
frame.searchBox:SetTextInsets(4, 4, 0, 0)

frame.searchButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
frame.searchButton:SetWidth(82)
frame.searchButton:SetHeight(23)
frame.searchButton:SetPoint("LEFT", frame.searchBox, "RIGHT", 10, 0)
frame.searchButton:SetText("Search")

frame.showAllCheck = CreateFrame("CheckButton", "WorldForgeMapShowAllCheck", frame, "UICheckButtonTemplate")
frame.showAllCheck:SetPoint("TOPLEFT", 24, -96)
_G[frame.showAllCheck:GetName() .. "Text"]:SetText("Show every World Forge object on the current zone map")
frame.showAllCheck:SetChecked(WorldForgeMap_Settings.showAllPins)
frame.showAllCheck:SetScript("OnClick", function(self)
    WorldForgeMap_Settings.showAllPins = self:GetChecked() and true or false
    WFM:ScheduleDraw(0.01)
end)

frame.hint = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.hint:SetPoint("TOPLEFT", 28, -128)
frame.hint:SetWidth(395)
frame.hint:SetJustifyH("LEFT")
frame.hint:SetText("Type an item/object name. Click a result to open the world map to that zone and highlight the pin.")

frame.results = {}
for i = 1, 13 do
    local b = CreateFrame("Button", nil, frame)
    b:SetWidth(400)
    b:SetHeight(23)
    b:SetPoint("TOPLEFT", 28, -153 - ((i - 1) * 24))
    b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")

    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.text:SetPoint("LEFT", 2, 0)
    b.text:SetWidth(400)
    b.text:SetJustifyH("LEFT")
    b.text:SetText("")

    b:SetScript("OnClick", function(self)
        if self.loc then WFM:OpenToLocation(self.loc) end
    end)

    b:SetScript("OnEnter", function(self)
        if not self.loc then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(self.loc.name or "Unknown", 1, 0.82, 0)
        GameTooltip:AddLine(tostring(self.loc.zoneName or self.loc.mapFile or "?") .. " - " .. CoordsText(self.loc), 1, 1, 1)
        if self.loc.itemId and self.loc.itemId > 0 then GameTooltip:AddLine("ItemId: " .. tostring(self.loc.itemId), 0.8, 0.8, 0.8) end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    frame.results[i] = b
end

frame.footer = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
frame.footer:SetPoint("BOTTOMLEFT", 24, 20)
frame.footer:SetWidth(410)
frame.footer:SetJustifyH("LEFT")
frame.footer:SetText("")

function WFM:RefreshSearchUI(query)
    query = query or frame.searchBox:GetText() or ""
    local results = self:Search(query)

    for i = 1, #frame.results do
        local b = frame.results[i]
        local loc = results[i]
        b.loc = loc
        if loc then
            b.text:SetText(string.format("%s  |cff999999%s %.1f, %.1f|r", tostring(loc.name), tostring(loc.zoneName or loc.mapFile), tonumber(loc.x or 0), tonumber(loc.y or 0)))
            b:Show()
        else
            b.text:SetText("")
            b:Hide()
        end
    end

    frame.footer:SetText(string.format("Showing %d of %d matches. Loaded: %d pins / %d names. Data: %s", math.min(#results, #frame.results), #results, self.total or 0, self.uniqueNames or 0, tostring(WorldForgeMap_ObjectLocationsVersion or "unknown")))
end

frame.searchButton:SetScript("OnClick", function() WFM:RefreshSearchUI(frame.searchBox:GetText()) end)
frame.searchBox:SetScript("OnEnterPressed", function(self) WFM:RefreshSearchUI(self:GetText()); self:ClearFocus() end)
frame.searchBox:SetScript("OnTextChanged", function(self) if frame:IsShown() then WFM:RefreshSearchUI(self:GetText()) end end)

function WFM:ToggleSearch()
    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
        frame.searchBox:SetFocus()
        frame.status:SetText(string.format("%d pins loaded / %d unique names", self.total or 0, self.uniqueNames or 0))
        frame.showAllCheck:SetChecked(WorldForgeMap_Settings.showAllPins)
        self:RefreshSearchUI(frame.searchBox:GetText())
    end
end

-- Minimap button
local function atan2(y, x)
    if x > 0 then return math.atan(y / x) end
    if x < 0 and y >= 0 then return math.atan(y / x) + math.pi end
    if x < 0 and y < 0 then return math.atan(y / x) - math.pi end
    if x == 0 and y > 0 then return math.pi / 2 end
    if x == 0 and y < 0 then return -math.pi / 2 end
    return 0
end

local mini = CreateFrame("Button", "WorldForgeMapMinimapButton", Minimap)
mini:SetWidth(32)
mini:SetHeight(32)
mini:SetFrameStrata("MEDIUM")
mini:SetFrameLevel(8)
mini:RegisterForClicks("LeftButtonUp", "RightButtonUp")
mini:RegisterForDrag("LeftButton")

mini.icon = mini:CreateTexture(nil, "BACKGROUND")
mini.icon:SetWidth(20)
mini.icon:SetHeight(20)
mini.icon:SetPoint("CENTER", 0, 1)
mini.icon:SetTexture(MINI_ICON_TEXTURE)

mini.overlay = mini:CreateTexture(nil, "OVERLAY")
mini.overlay:SetWidth(54)
mini.overlay:SetHeight(54)
mini.overlay:SetPoint("TOPLEFT")
mini.overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
mini:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

function WFM:UpdateMinimapButton()
    local angle = WorldForgeMap_Settings.minimapAngle or 225
    local radius = 80
    local radians = math.rad(angle)
    mini:ClearAllPoints()
    mini:SetPoint("CENTER", Minimap, "CENTER", math.cos(radians) * radius, math.sin(radians) * radius)
end

mini:SetScript("OnClick", function(self, button)
    if button == "RightButton" then
        Print("/wfm - open search")
        Print("/wfm search name - search directly")
        Print("/wfm count - show loaded/current zone pin counts")
        Print("/wfm gps off - clear the GPS arrow")
        Print("/wfm showall or /wfm hideall")
    else
        WFM:ToggleSearch()
    end
end)

mini:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
        local mx, my = Minimap:GetCenter()
        local px, py = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        px = px / scale
        py = py / scale
        WorldForgeMap_Settings.minimapAngle = math.deg(atan2(py - my, px - mx))
        WFM:UpdateMinimapButton()
    end)
end)

mini:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)

-- Slash commands
SLASH_WORLDFORGEMAP1 = "/wfm"
SLASH_WORLDFORGEMAP2 = "/worldforge"

SlashCmdList["WORLDFORGEMAP"] = function(msg)
    msg = msg or ""
    local cmd, rest = string.match(msg, "^(%S*)%s*(.-)$")
    cmd = string.lower(cmd or "")
    rest = rest or ""

    if cmd == "" or cmd == "open" then
        WFM:ToggleSearch()
        return
    end

    if cmd == "search" or cmd == "find" then
        frame.searchBox:SetText(rest)
        if not frame:IsShown() then frame:Show() end
        WFM:RefreshSearchUI(rest)
        local results = WFM:Search(rest)
        if results[1] then WFM:OpenToLocation(results[1]) else Print("No match for: " .. rest) end
        return
    end

    if cmd == "count" then
        local mapFile = CurrentMapFile()
        Print(string.format("Loaded %d pins / %d unique names. Current map: %s (%s), pins here: %d. Data: %s", WFM.total or 0, WFM.uniqueNames or 0, tostring(CurrentZoneName() or "?"), tostring(mapFile or "?"), WFM:ZoneCount(mapFile), tostring(WorldForgeMap_ObjectLocationsVersion or "unknown")))
        return
    end

    if cmd == "showall" then
        WorldForgeMap_Settings.showAllPins = true
        frame.showAllCheck:SetChecked(true)
        Print("Showing all World Forge pins on the current world map zone.")
        WFM:ScheduleDraw(0.01)
        return
    end

    if cmd == "hideall" then
        WorldForgeMap_Settings.showAllPins = false
        frame.showAllCheck:SetChecked(false)
        Print("Only selected/search result pins will show.")
        WFM:ScheduleDraw(0.01)
        return
    end

    if cmd == "gps" or cmd == "arrow" then
        if rest == "off" or rest == "clear" or rest == "hide" then
            WFM.gpsTarget = nil
            WFM:ClearTomTomWaypoint()
            gpsFrame:Hide()
            Print("GPS cleared.")
            return
        end
        if rest ~= "" then
            local results = WFM:Search(rest)
            if results[1] then
                WFM:OpenToLocation(results[1])
                WFM:SetGPSTarget(results[1])
            else
                Print("No GPS match for: " .. rest)
            end
            return
        end
        Print("Usage: /wfm gps item name  or  /wfm gps off")
        return
    end

    if cmd == "debug" then
        local mapFile = CurrentMapFile()
        local geom = GetMapGeometry()
        Print("MapFile=" .. tostring(mapFile) .. ", ZoneName=" .. tostring(CurrentZoneName()) .. ", PinsHere=" .. tostring(WFM:ZoneCount(mapFile)))
        if geom then Print(string.format("MapGeom left=%.1f bottom=%.1f width=%.1f height=%.1f offset=%.1f,%.1f", geom.left or 0, geom.bottom or 0, geom.width or 0, geom.height or 0, geom.offsetX or 0, geom.offsetY or 0)) end
        return
    end

    -- Unknown command = search phrase, so /wfm storage crate works.
    frame.searchBox:SetText(msg)
    if not frame:IsShown() then frame:Show() end
    WFM:RefreshSearchUI(msg)
end

-- Events and map hooks
local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:SetScript("OnEvent", function(self, event, name)
    if name ~= ADDON then return end
    WFM:BuildIndexes()
    WFM:UpdateMinimapButton()

    if (WFM.total or 0) == 0 then
        Print("Loaded, but no object database is installed.")
    else
        Print(string.format("Loaded %d World Forge pins / %d names. Use /wfm or the minimap button.", WFM.total or 0, WFM.uniqueNames or 0))
    end
end)

if WorldMapFrame then
    WorldMapFrame:HookScript("OnShow", function() WFM:ScheduleDraw(0.15) end)
    WorldMapFrame:HookScript("OnHide", function() WFM:HidePins() end)
end

if WorldMapButton then
    WorldMapButton:HookScript("OnShow", function() WFM:ScheduleDraw(0.10) end)
    WorldMapButton:HookScript("OnMouseUp", function(self, button)
        WFM:HandleMapClick(button)
        WFM:ScheduleDraw(0.05)
    end)
end

-- Watch dropdown/map changes. This fixes the case where the world map is already open and
-- the player changes zones with the built-in dropdowns.
local watcher = CreateFrame("Frame")
watcher.elapsed = 0
watcher.lastMapFile = nil
watcher:SetScript("OnUpdate", function(self, elapsed)
    self.elapsed = self.elapsed + elapsed
    if self.elapsed < 0.25 then return end
    self.elapsed = 0

    if WorldMapFrame and WorldMapFrame:IsShown() then
        local mf = CurrentMapFile()
        if mf ~= self.lastMapFile then
            self.lastMapFile = mf
            WFM:ScheduleDraw(0.05)
        end
    else
        HidePinHoverLabel()
    end
end)

-- Some 3.3.5 world-map layers sit above custom child buttons, so button OnEnter
-- can be swallowed even when the pin texture is visible. This cursor scanner makes
-- hover labels reliable by checking the mouse position against drawn pin coords.
local hoverWatcher = CreateFrame("Frame")
hoverWatcher.elapsed = 0
hoverWatcher:SetScript("OnUpdate", function(self, elapsed)
    self.elapsed = self.elapsed + elapsed
    if self.elapsed < 0.025 then return end
    self.elapsed = 0

    if WorldMapFrame and WorldMapFrame:IsShown() then
        WFM:UpdateManualHover()
    else
        HidePinHoverLabel()
    end
end)
