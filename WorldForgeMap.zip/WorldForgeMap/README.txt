WorldForgeMap 1.2 - Restore Diamonds + TomTom-Independent GPS

This build restores the proven visible diamond pin placement from 0.9, but keeps the GPS math isolated from TomTom/waypoint addons.

Changes:
- Diamonds are drawn on the normal 3.3.5 WorldMapButton surface again, so they show properly.
- Removed WorldMapButton mouse-up GPS hook to avoid sharing TomTom's map-click chain.
- Left-clicking a diamond still sets WorldForgeMap's built-in GPS panel.
- GPS never calls TomTom, Astrolabe, CrazyArrow, /way, or waypoint APIs.
- GPS briefly selects the target zone, reads Blizzard GetPlayerMapPosition for that target zone, then restores the map state.

Commands:
/wfm
/wfm search item name
/wfm gps item name
/wfm gps off
/wfm count
/wfm debug
/wfm showall
/wfm hideall
