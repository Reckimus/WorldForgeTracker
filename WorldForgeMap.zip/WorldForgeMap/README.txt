WorldForgeMap 1.9 - Original Working Hover Restored

This build is based on the uploaded WorldForgeMap.zip that had working map hover labels.

Changes from that working build:
- Restored the original diamond hover logic instead of the later experimental scanner/UIParent versions.
- Keeps the original GameTooltip-over-world-map behavior only while the world map is open.
- Resets Blizzard's shared GameTooltip back to UIParent when pin hover ends or the world map closes.
- Keeps the built-in GPS fallback and ignores TomTom/waypoint addons.

Commands:
/wfm
/wfm search item name
/wfm gps item name
/wfm gps off
/wfm count
/wfm debug
/wfm showall
/wfm hideall
